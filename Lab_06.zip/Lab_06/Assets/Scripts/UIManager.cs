using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI livesText;
    public int startLives = 3;
    public int score = 0;
    private int lives;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject); 
            return;
        }

        Instance = this;
    }
    void Start()
    {
        lives = startLives;
        UpdateScoreUI();
        UpdateLivesUI();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void AddScore(int amount)
    {
        score += amount;
        UpdateScoreUI();
    }

    void UpdateScoreUI()
    {
        scoreText.text = "Score: " + score.ToString();
    }

    public void SetLives(int newLives)
    {
        lives = newLives;
        UpdateLivesUI();
    }

    public void UpdateLivesUI()
    {
        livesText.text = "Lives: " + lives.ToString();
    }
}
