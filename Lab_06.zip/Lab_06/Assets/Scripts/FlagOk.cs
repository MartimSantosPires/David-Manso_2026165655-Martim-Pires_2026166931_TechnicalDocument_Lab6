using UnityEditor.VersionControl;
using UnityEngine;
using UnityEngine.Audio;
using static UnityEngine.Rendering.DebugUI;

public class FlagOk : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        // Verifica se o objeto que colidiu com a bandeira � o jogador
        if (other.CompareTag("Player"))
        {
            Debug.Log("Level completed!");
        }
    }
}
