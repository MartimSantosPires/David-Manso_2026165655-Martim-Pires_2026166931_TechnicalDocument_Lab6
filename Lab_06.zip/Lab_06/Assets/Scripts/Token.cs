using UnityEngine;

[RequireComponent(typeof(BoxCollider))] 
public class Token : MonoBehaviour
{
    
    public static int Value;
    public AudioClip pickupSfx;
    private AudioSource audioSource;

    void Awake()
    {
       
        Collider col = GetComponent<Collider>();
        if (col != null)
        {
            col.isTrigger = true;
        }

        
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;
    }

    void OnTriggerEnter(Collider other)
    {
    
        if (other.CompareTag("Player"))
        {
            Destroy(gameObject);
        }

       
        if (UIManager.Instance != null)
        {
            UIManager.Instance.AddScore(Value);
        }

        
        if (pickupSfx != null && audioSource != null)
        {
            audioSource.PlayOneShot(pickupSfx);
        }
    }
}